import os
import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

class DocIndexer:
    def __init__(self, dir_path):
        self.dir_path = dir_path
        self.docs = self.load_docs()
        self.vectorizer = TfidfVectorizer(stop_words='english', token_pattern=r"(?u)\b\w+\b")
        self.tf_matrix = self.calc_tf_matrix()
        self.index = self.build_index()

    def load_docs(self):
        documents = []
        for filename in os.listdir(self.dir_path):
            with open(os.path.join(self.dir_path, filename), 'r', encoding='utf-8') as file:
                content = file.read()
                documents.append((filename, content))
        return documents

    def calc_tf_matrix(self):
        return self.vectorizer.fit_transform([doc[1] for doc in self.docs])

    def build_index(self):
        index = {}
        terms = self.vectorizer.get_feature_names_out()
        for filename, content in self.docs:
            doc_index = {}
            tfidf_scores = self.tf_matrix[self.docs.index((filename, content))].toarray()[0]
            for j, term in enumerate(terms):
                score = tfidf_scores[j]
                if score > 0:
                    doc_index[term] = score
            index[filename] = doc_index
        return index

    def save_to_pickle(self, output_file):
        with open(output_file, 'wb') as f:
            pickle.dump({
                'index': self.index,
                'doc_names': [doc[0] for doc in self.docs],
                'tf_matrix': self.tf_matrix,
                'similarity_matrix': self.calc_similarity_matrix().tolist(),
                'vectorizer': self.vectorizer
            }, f)

    def display_tfidf_scores(self):
        terms = self.vectorizer.get_feature_names_out()
        for doc_name, doc_index in self.index.items():
            print(f"Document: {doc_name}")
            for term in terms:
                if term in doc_index:
                    print(f"\tTerm: {term}, TF-IDF Score: {doc_index[term]}")

    def calc_similarity_matrix(self):
        cosine_similarities = cosine_similarity(self.tf_matrix, self.tf_matrix)
        return cosine_similarities

    def display_similar_docs(self):
        doc_names = list(self.index.keys())
        for i, doc_name in enumerate(doc_names):
            print(f"Document: {doc_name}")
            sim_docs_indices = np.argsort(self.calc_similarity_matrix()[i])[-4:-1][::-1]
            for j, idx in enumerate(sim_docs_indices):
                if idx != i:
                    sim_doc_name = doc_names[idx]
                    sim_score = self.calc_similarity_matrix()[i, idx]
                    print(f"\tSimilar Document {j+1}: {sim_doc_name}, Cosine Similarity: {sim_score:.4f}")

# Usage
indexer = DocIndexer('output')  # Assuming 'output' is the folder containing HTML files
indexer.display_tfidf_scores()
print("\n")
indexer.display_similar_docs()
indexer.save_to_pickle('index.pickle')
