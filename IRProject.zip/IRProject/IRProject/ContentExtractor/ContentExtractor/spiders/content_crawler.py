import scrapy
import os

class WebDocumentSpider(scrapy.Spider):
    name = 'content_crawler'

    def __init__(self, *args, **kwargs):
        super(WebDocumentSpider, self).__init__(*args, **kwargs)
        # Seed URLs to start crawling
        self.start_urls = [
            'https://en.wikipedia.org/wiki/World_War_II',
            'https://en.wikipedia.org/wiki/Albert_Einstein',
            'https://en.wikipedia.org/wiki/Leonardo_da_Vinci',
            'https://en.wikipedia.org/wiki/SpaceX',
            'https://en.wikipedia.org/wiki/Climate_change',
            'https://en.wikipedia.org/wiki/COVID-19_pandemic'
        ]

    def parse(self, response):
        # Extracting the content of the web page
        content = response.body

        # Get the page title
        page_title = response.css('title::text').get()

        if page_title:
            # Create the output folder if it doesn't exist
            output_folder = 'output'
            os.makedirs(output_folder, exist_ok=True)

            # Save the content to a file with the page title as the filename
            filename = f'{output_folder}/{page_title}.html'
            with open(filename, 'wb') as f:
                f.write(content)
            self.log(f'Saved file {filename}')

    @classmethod
    def from_crawler(cls, crawler, *args, **kwargs):
        spider = super(WebDocumentSpider, cls).from_crawler(crawler, *args, **kwargs)
        crawler.signals.connect(spider.spider_closed, signal=scrapy.signals.spider_closed)
        return spider

    def spider_closed(self, spider):
        self.logger.info('Spider closed: %s', spider.name)
