import os
import pickle
from flask import Flask, request, jsonify
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import re

# Initialize Flask app
app = Flask(__name__)

# Load the pre-built index from pickle
with open("index.pickle", "rb") as f:
    index_data = pickle.load(f)

# Extract index components
index = index_data["index"]
doc_names = index_data["doc_names"]
tf_matrix = index_data["tf_matrix"]
vectorizer = index_data["vectorizer"]

# Function to validate query
def validate_query(query):
    if not isinstance(query, str):
        return False, "Query must be a string."
    if len(query.strip()) == 0:
        return False, "Query cannot be empty."
    if not re.match(r"^[\w\s.,'!?-]+$", query):
        return False, "Query contains invalid characters."
    return True, ""

# Route to process text-based queries
@app.route("/query", methods=["POST"])
def process_query():
    data = request.get_json()

    # Check if the query is provided in the expected format
    if "query" not in data:
        return jsonify({"error": "Missing 'query' field in request."}), 400

    query = data["query"]
    is_valid, error_msg = validate_query(query)

    if not is_valid:
        return jsonify({"error": error_msg}), 400

    # Convert query into a TF-IDF vector
    query_vector = vectorizer.transform([query])

    # Calculate cosine similarity with the indexed documents
    cosine_similarities = cosine_similarity(query_vector, tf_matrix)

    # Get the top-K documents based on cosine similarity
    K = 5
    top_k_indices = np.argsort(-cosine_similarities[0])[:K]
    top_k_results = [
        {"document": doc_names[i], "similarity": float(cosine_similarities[0, i])}
        for i in top_k_indices
    ]

    # Return the top-K similar documents in JSON format
    return jsonify({"top_5_results": top_k_results}), 200

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=3000)
